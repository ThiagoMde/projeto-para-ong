from datetime import datetime
class Animal:
    contador_global = 0
    def __init__(self,nome, data_nascimento, especie, porte, pelagem):
        Animal.contador_global += 1
        self.numero = Animal.contador_global
        self.nome = nome
        self.data_nascimento = data_nascimento
        self.especie = especie
        self.porte = porte
        self.pelagem = pelagem

    def __str__(self):
        return (f"identificador - {self.numero}, Nome: {self.nome}, Data de Nascimento: {self.data_nascimento}, "
                f"Espécie: {self.especie}, Porte: {self.porte}, Pelagem: {self.pelagem}")

animais = []

def cadastrar_animal( nome, data_nascimento, especie, porte, pelagem):
    novo_animal = Animal (nome, data_nascimento, especie, porte, pelagem)
    animais.append(novo_animal)

def listar_animais():
    for animal in animais:
        print(animal)



def adotar_animal(especie, porte):
    animais_filtrados = [animal for animal in animais if animal.especie == especie and animal.porte == porte]
    if not animais_filtrados:
        print("Nenhum animal encontrado com os critérios informados.")
        return

    for animal in animais_filtrados:
        print(animal)

  

    print("Identificador não encontrado.")

import tkinter as tk
from tkinter import simpledialog, messagebox

class App:
    contador = 0
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Adoção de Animais")
        self.create_widgets()

    def create_widgets(self):
        tk.Button(self.root, text="Cadastrar Animal", command=self.cadastrar_animal).pack(pady=20)
        tk.Button(self.root, text="Listar Animais", command=self.listar_animais).pack(pady=20)
        tk.Button(self.root, text="Adotar Animal", command=self.adotar_animal).pack(pady=20)

    def cadastrar_animal(self):
        
        
        nome = simpledialog.askstring("Entrada", "Nome:")
        while True:
            data_nascimento_str = simpledialog.askstring("Entrada", "Data de Nascimento(DD/MM/AAAA):")
            try:
                data_nascimento = datetime.strptime(data_nascimento_str, "%d/%m/%Y").date()
                break
            except ValueError:
                messagebox.showinfo("ERRO", "Data invalida, tente novamente!")
            
        
        especie = simpledialog.askstring("Entrada", "Espécie (cachorro ou gato):")
        porte = simpledialog.askstring("Entrada", "Porte (pequeno, médio, grande):")
        pelagem = simpledialog.askstring("Entrada", "Pelagem:")
        
        cadastrar_animal(nome, data_nascimento, especie, porte, pelagem)
        messagebox.showinfo("Informação", "Animal cadastrado com sucesso!")
        self.contador += 1


    def listar_animais(self):
        lista = "\n".join(str(animal) for animal in animais)
        messagebox.showinfo("Animais Disponíveis", lista if lista else "Nenhum animal disponível.")
        print(self.contador)
    def adotar_animal(self):
        especie = simpledialog.askstring("Entrada", "Espécie (cachorro ou gato):")
        porte = simpledialog.askstring("Entrada", "Porte (pequeno, médio, grande):")
        
        animais_filtrados = [animal for animal in animais if animal.especie == especie and animal.porte == porte]
        if not animais_filtrados:
            messagebox.showinfo("Informação", "Nenhum animal encontrado com os critérios informados.")
            return

        lista = "\n".join(str(animal) for animal in animais_filtrados)
        nome = simpledialog.askstring("Entrada", f"Animais disponíveis:\n{lista}\n\nInforme o nome do animal que deseja adotar:")
        
        
        for animal in animais_filtrados:
            if animal.nome == nome:
                animais.remove(animal)
                messagebox.showinfo("Informação", f"Animal {animal.nome} adotado com sucesso!")
                return

        messagebox.showinfo("Erro", "Animal não encontrado.")

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.geometry("300x400")
    root.mainloop()
